from tkinter import *
import os
import random
window = Tk()


window.title('Random Email Generator')
window.minsize(width=400,height=400)
window.maxsize(width=400,height=400)
window.resizable(False,False)
window.config(bg='light blue')


lenght = Scale(
    orient='horizontal',
    from_=1,to=20,
    sliderlength=10,
    length=240,
    fg='white',
    bg='light blue',
    activebackground='light blue',
    )
lenght.place(x=90,y=30)
def email_generator():
    try:
        first_part = '@gmail.com'
        alphabets = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r',   's','t','u','v','w','x','y','z']
        res_email = ''
        length_email = lenght.get()
        for i in range(length_email):
            email=random.choice(alphabets)
            res_email = res_email+email
            
            
            
        full_email = res_email+first_part
        res = Label(text=full_email,font=('Arial',15),bg='light blue')
        res.place(x=80,y=150)

    except:
        print('Erro Occur while executing the statement')
    


btn = Button(text='Generate Email',bg='light blue',activebackground='light blue',font=('Arial',15),command=email_generator)
btn.place(x=130,y=100)





window.mainloop()